# Kovacs-Birovits-Lazar
Ide tudjuk commit-olni a kész munkákat.
